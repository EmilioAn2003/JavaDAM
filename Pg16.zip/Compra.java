package pg16;

public class Compra {
	
	int idCompra;
	Cliente cliente;
	double importe;
	Fecha fecha;
	
	public Compra(int idCompra, Cliente cliente, double importe, Fecha fecha) {
		super();
		this.idCompra = idCompra;
		this.cliente = cliente;
		this.importe = importe;
		this.fecha = fecha;
	}
	
	public int getIdCompra() { return idCompra; }
	public Cliente getCliente() { return cliente; }
	public double getImporte() {return importe;	}
	public Fecha getFecha() {return fecha;}
	
	public void setIdCompra(int idCompra) {this.idCompra = idCompra;}
	public void setCliente(Cliente cliente) {this.cliente = cliente;}
	public void setImporte(double importe) {this.importe = importe;}
	public void setFecha(Fecha fecha) {	this.fecha = fecha;}
	
}
