package pg16;

import java.util.ArrayList;
import java.util.Scanner;


public class ProgramaIMC {
	
	public static void main(String[] args) {
        
        ArrayList<Persona> personas= new ArrayList<Persona>(); 
        
        System.out.println("Lista Vacia");
        
        while(pedirBoolean("Añadir persona: ")){
        	personas.add(damePersona());
        }
        
        System.out.println("Personas con IMC");
        for(Persona p:personas) if(p.getBooleanIMC()) System.out.println(p.getRegistro()); 
        
        System.out.println("Personas sin IMC");
        for(Persona p:personas) if(!p.getBooleanIMC()) System.out.println(p.getRegistro()); 
    }

    public static Persona damePersona(){
        
        Persona p =new Persona(pedirString("Nombre: "));
        
        if(pedirBoolean("Dispone del peso y la estatura: ")){
        	p.setPeso(pedirDouble("Peso: "));
        	p.setEstatura(pedirDouble("Estatura: "));
    		p.setIMC(p.getPeso(), p.getEstatura());
        }
        
        return p;
    }
    
    public static boolean pedirBoolean(String pregunta){
        String input;
        do {
        	input=pedirString(pregunta+"(S/N) ");
        }while(!(input.equals("S")||input.equals("N")));
        return input.equals("S");
    }

    public static double pedirDouble(String pregunta){
        boolean incorrectInput;
        double num=0;
        do {
        	incorrectInput=false;
        	try{ num=Double.parseDouble(pedirString(pregunta)); }catch(Exception e) { incorrectInput=true; }
        }while(incorrectInput);
        return num;
    }
    
    public static String pedirString(String pregunta){
    	System.out.print(pregunta);
    	Scanner sc= new Scanner(System.in);
    	return sc.next();
    }
}
