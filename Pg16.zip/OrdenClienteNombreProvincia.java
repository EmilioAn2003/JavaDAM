package pg16;

import java.util.Comparator;

public class OrdenClienteNombreProvincia implements Comparator<Cliente>{
	
	@Override
	public int compare(Cliente cl1, Cliente cl2) {
		int orden = cl1.provincia.compareToIgnoreCase(cl2.provincia);
		if(orden==0) orden = cl1.nombre.compareToIgnoreCase(cl2.nombre);
		return orden;
	}
	
}
