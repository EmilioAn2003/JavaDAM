package pg16;

import java.util.Comparator;

public class OrdenCandidatoFecha implements Comparator<Candidato>{
	
	@Override
	public int compare(Candidato c1, Candidato c2) {
		
		int orden=c1.getApellido1().compareToIgnoreCase(c2.getApellido1());
		
		try {
			if(orden==0) orden=c1.getApellido2().compareToIgnoreCase(c2.getApellido2());
		}catch(Exception e) {
			if(c1.getApellido2()==null) orden--;
			if(c2.getApellido2()==null) orden++;
		}
		
		if(orden==0) orden=c1.getNombre().compareToIgnoreCase(c2.getNombre());
		
		return orden;
	}
}
