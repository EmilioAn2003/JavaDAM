package pg16;

import java.util.ArrayList;
import java.util.Collections;

public class Principal12 {
	
	public static Fecha hoy;
	
	public static void main(String[] args) {
		
		hoy=new Fecha(1, 3, 2023);
		
		Fecha mesPasado=new Fecha(31, 2, 2023 );
		Fecha manyana=new Fecha(2, 3, 2023 );
		Fecha añoPasado=new Fecha(1, 3, 2022 );
		
		Cliente cl1=new Cliente(1,"Emilio","Av Alfonso X","Murcia", new ArrayList<Compra>());
		cl1.getListaCompras().add(new Compra(1, cl1, 10, hoy));
		cl1.getListaCompras().add(new Compra(2, cl1, 10, mesPasado));
		
		Cliente cl2=new Cliente(2,"Juan","Av Alfonso X","Madrid", new ArrayList<Compra>());
		cl2.getListaCompras().add(new Compra(3, cl2, 10, añoPasado));
		cl2.getListaCompras().add(new Compra(4, cl2, 10, mesPasado));
		
		Cliente cl3=new Cliente(3,"alvaro","Av Alfonso X","Murcia", new ArrayList<Compra>());
		cl3.getListaCompras().add(new Compra(5, cl3, 10, añoPasado));
		cl3.getListaCompras().add(new Compra(6, cl3, 10, manyana));
		
		Cliente cl4=new Cliente(4,"leon","Av Alfonso X","Madrid", new ArrayList<Compra>());
		cl4.getListaCompras().add(new Compra(7, cl4, 10, mesPasado));
		cl4.getListaCompras().add(new Compra(8, cl4, 10, mesPasado));
		
		ArrayList<Cliente> clientes=new ArrayList<Cliente>();
		clientes.add(cl1); clientes.add(cl2); clientes.add(cl3); clientes.add(cl4);
		
		ArrayList<Cliente> clientesOtroMes=listaClientes(clientes);
		for(Cliente cl:clientesOtroMes) System.out.println(cl.toString());
	}
	
	public static ArrayList<Cliente> listaClientes (ArrayList<Cliente> clientes){
		ArrayList<Cliente> cls= new ArrayList<Cliente>();
		for(Cliente cl:clientes) if(!clienteDelMes(cl)) cls.add(cl);
		Collections.sort(cls, new OrdenClienteNombreProvincia());
		return cls;
	}
	public static boolean clienteDelMes (Cliente cliente){
		for(Compra compraCl: cliente.getListaCompras()) if(compraCl.getFecha().mismoMes(hoy)) return true;
		return false;
	}
}
