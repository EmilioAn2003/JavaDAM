package pg16;

public class Buscaminas {

	private static char[][] area = { { '0', '0', '0', '0', '0', '0' }, 
									 { '0', '0', '0', '0', '0', '0' },
									 { '0', '0', '0', '0', '0', '0' }, 
									 { '0', '0', '0', '0', '0', '0' }, 
									 { '0', '0', '0', '0', '0', '0' },
									 { '0', '0', '0', '0', '0', '0' } };

	public static void main(String[] args) {
		
		System.out.println(celdasSeguras());
	
	}

	public static int celdasSeguras() {
		
		int celdasSeguras = 0;
		
		for (int x = 0; x < area.length; x++) 
		for (int y = 0; y < area[x].length; y++) 
			if(celdaSegura(x, y)) celdasSeguras++;
		
		return celdasSeguras;
	}

	public static boolean celdaSegura(int x, int y) {
		
		boolean segura = true;
		
		for (int cambiax = -1; cambiax < 2; cambiax++) 
		for (int cambiay = -1; cambiay < 2; cambiay++) 
			try {
				segura = segura && area[x + cambiax][y + cambiay] == '0';
			} catch (Exception e) {}
		
		
		return segura;
	}
}
