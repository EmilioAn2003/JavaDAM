package pg16;

import java.util.ArrayList;
import java.util.Collections;

public class Principal11 {

	public static void main(String[] args) {
		System.out.println(null==null);

	}
	
	public static ArrayList<Candidato> admitidos (ArrayList<Candidato> candidatos, ArrayList<Candidato> descartados){
		
		candidatos.removeAll(descartados);
		Collections.sort(candidatos);
		
		ArrayList<Candidato> admitidos= new ArrayList<Candidato>();
		
		for(Candidato c:candidatos) {
			if(admitidos.size()==20) return admitidos;
			admitidos.add(c);
		}
		
		return admitidos;
	}
	
	public static ArrayList<Candidato> ordenar(ArrayList<Candidato> candidatos){
		Collections.sort(candidatos, new OrdenCandidatoFecha());
		return candidatos;
	}
}
