package pg16;

public class Matriz {

	public static void main(String[] args) {

		char[][] mGrande = new char[10][10];

		for (int f = 0; f < mGrande.length; f++) {
			for (int c = 0; c < mGrande[f].length; c++) {
				mGrande[f][c] = (char) (Math.random() * ('D' - 'A') + 'A' + 0.5);
				System.out.print(mGrande[f][c] + " ");
			}
			System.out.println();
		}

		char[][] mPequenya = { { 'A', 'B' }, { 'C', 'D' } };

		System.out.println(matrizContenida(mGrande, mPequenya));
	}
 
	public static boolean matrizContenida(char[][] mGrande, char[][] mPequenya) {

		for (int FM = 0; FM < mGrande.length; FM++) 
		for (int CM = 0; CM < mGrande[FM].length; CM++) 
			if(matrizContenida(mGrande, mPequenya, FM, CM)) return true;

		return false;
	}

	public static boolean matrizContenida(char[][] mGrande, char[][] mPequenya, int FM, int CM) {

		for (int fm = 0; fm < mPequenya.length; fm++) 
		for (int cm = 0; cm < mPequenya[fm].length; cm++) 
			try { 
				if( mGrande[FM + fm][CM + cm] != mPequenya[fm][cm] ) return false;
			} catch (Exception e) {  return false; }

		return true;
	}
}
