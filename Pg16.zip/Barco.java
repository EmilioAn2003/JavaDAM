package pg16;

import java.util.Scanner;

public class Barco {
	private static char[][] area = { 	{ '0', '0', '0', '0', '0', '0' }, 
										{ '0', '0', '0', '0', '0', '0' },
										{ '0', '0', '0', '0', '0', '0' }, 
										{ '0', '0', '0', '0', '0', '0' }, 
										{ '0', '0', '0', '0', '0', '0' } };
	private static int barcoLength = 4;
	private static int errores = 0;
	private static boolean vertical = Math.random() < 0.5;

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		mostrarArea();
		generarBarco();
		
		do {
			int f = 0, c = 0;

			String sNum;
			boolean incorrectF = true, incorrectC = true;

			do {
				System.out.println("Introduce tus coordenadas:");

				sNum = sc.nextLine();
				try { f = Integer.parseInt(sNum); incorrectF = f >= area.length || f < 0; } catch (Exception e) {}

				sNum = sc.nextLine();
				try { c = Integer.parseInt(sNum); incorrectC = c >= area[0].length || c < 0; } catch (Exception e) {}

			} while (incorrectF || incorrectC);

			if (area[f][c] == '*')  System.out.println("Disparo ya realizado");	
			if (area[f][c] == '0'){ System.out.println("Fallaste!!"); errores++; }
			if (area[f][c] == '#')  System.out.println("Acertaste!!");				

			area[f][c] = '*';

		} while (errores < 3 && jugando());

		System.out.println(errores < 3 ? "Ganaste" : "Perdiste");
		mostrarArea();
		sc.close();
	}

	public static void generarBarco() {
		
		int f,c;
		f = vertical?  (int)(Math.random() * (area.length-barcoLength) +0.5)    : (int)(Math.random()*area.length);
		c = !vertical? (int)(Math.random() * (area[f].length-barcoLength) +0.5) : (int)(Math.random()*area[f].length) ;

		for (int i = 0; i < barcoLength; i++) {
			
			if (vertical)  area[f+i][c] = '#';
			if (!vertical) area[f][c+i] = '#';
		
		}
	}

	public static void mostrarArea() {

		for (char[] f : area) {
		for (char c : f) System.out.print(c + " ");
			System.out.println();
		}
	}

	public static boolean jugando() {
		for (char[] lista : area) 
		for (char elemento : lista) 
			if (elemento == '#') return true;
		
		return false;
	}
}
