package pg16;

public class Fecha {
	
	private int dia;
	private int mes;
	private int anyo;
	
	public Fecha(int dia, int mes, int anyo) {
		this.dia = dia;
		this.mes = mes;
		this.anyo = anyo;
	}
	
	public int getDia() {return dia;}
	public int getMes() {return mes;}
	public int getAnyo() {return anyo;}
	
	public void setDia(int dia) {this.dia = dia;}
	public void setMes(int mes) {this.mes = mes;}
	public void setAnyo(int anyo) {this.anyo = anyo;}
	
	public int compareTo(Fecha f) {
		if(this.anyo!=f.getAnyo()) 	return this.anyo-f.getAnyo();
		if(this.mes!=f.getMes()) 	return this.mes-f.getMes();
		if(this.dia!=f.getDia())	return this.dia-f.getDia();
		return 0;
	}
	
	public boolean mismoMes(Fecha f) {
		if(this.anyo!=f.getAnyo()) return false;
		if(this.mes!=f.getMes()) return false;
		return true;
	}
}
