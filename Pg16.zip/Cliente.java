package pg16;

import java.util.ArrayList;

public class Cliente{
	
	int idCliente;
	String nombre;
	String direccion;
	String provincia;
	ArrayList<Compra> listaCompras;
	
	public Cliente(int idCliente, String nombre, String direccion, String provincia, ArrayList<Compra> listaCompras) {
		super();
		this.idCliente = idCliente;
		this.nombre = nombre;
		this.direccion = direccion;
		this.provincia = provincia;
		this.listaCompras = listaCompras;
	}
	
	public int getIdCliente() {return idCliente;}
	public String getNombre() {return nombre;}
	public String getDireccion() {return direccion;}
	public String getProvincia() {return provincia;}
	public ArrayList<Compra> getListaCompras() {return listaCompras;}
	
	public void setIdCliente(int idCliente) {this.idCliente = idCliente;}
	public void setNombre(String nombre) {this.nombre = nombre;}
	public void setDireccion(String direccion) {this.direccion = direccion;}
	public void setProvincia(String provincia) {this.provincia = provincia;}
	public void setListaCompras(ArrayList<Compra> listaCompras) {this.listaCompras = listaCompras;}
	
	@Override
	public String toString() {
		return "Cliente "+idCliente+ " [" + provincia + ", " + nombre + "]";
	}
	
}

