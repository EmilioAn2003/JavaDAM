package pg16;

public class SopaDeLetras {

	public static char[][] sopa;
	public static String palabras[] = {"PERA","MANZANA","PLATANO","CIRUELA"};

	public static void main(String[] args) {

		introducirPalabras();
		rellenarSopa();
		verSopa();

	}

	public static void introducirPalabras() {
		
		int l = maxLenght();
		sopa = new char[l][l];
		
		for (String p : palabras) introducirPalabras(p); 

	}

	public static int maxLenght() {
		
		int largo = 0;
		
		for (String p : palabras) if(largo < p.length()) largo = p.length();
		
		return largo;
	}
	
	public static void introducirPalabras(String palabra) {
		
		boolean noCabe,vertical;
		int f,c;
		
		do{
			vertical = Math.random()>0.5;
			f= (int)(Math.random()*sopa.length);
			c= (int)(Math.random()*sopa[f].length);
			
			noCabe=!cabe(palabra, f, c, vertical );
		}while(noCabe);
		
		for (int i=0; i<palabra.length(); i++) {
			sopa[f][c]=palabra.charAt(i);
			if(vertical)  f++;
			if(!vertical) c++;
		}
		 
	}
	public static boolean cabe(String palabra, int f,int c, boolean vertical) {
		boolean cabe=true;
		
		for (int i=0; i<palabra.length() && cabe; i++) {
			
			try { 
				if(sopa[f][c]>='A' && sopa[f][c]<='Z') cabe = cabe&&sopa[f][c]==palabra.charAt(i);
			}catch(Exception e) { 
				cabe=false; 
			}
			
			if(vertical)  f++;
			if(!vertical) c++;
		}
		
		return cabe;
	}
	
	public static void verSopa() {
		for (char[] f : sopa) {
		for (char c : f) System.out.print(c + "|");
			System.out.println("");
		}
	}

	public static void rellenarSopa() {
		for(int f=0; f<sopa.length; f++) 
		for(int c=0; c<sopa[f].length; c++) 
			if(sopa[f][c]<'A' || sopa[f][c]>'Z') sopa[f][c]= (char) (Math.random() * ('Z' - 'A') + 'A' + 0.5);
	}
}
