package pg16;

public class Persona {

    private String name;
    private double peso;
    private double estatura;
    private double IMC;
    private boolean booleanIMC;
    
    public Persona(String name){
        this.name=name;
        this.booleanIMC=false;
    }
    public Persona(String name, double peso, double estatura){
        this.name=name;
        this.peso=peso;
        this.estatura=estatura;
        this.IMC=peso/(estatura*estatura);
        this.booleanIMC=true;
    }
    public String getRegistro(){
    	if(booleanIMC) return name+", "+peso+", "+estatura+", "+IMC;
    	else return name;
    }
    
    public void setNombre(String name){ this.name=name; }
    public String getNombre(){ return name; }
    
    public void setPeso(double peso){ this.peso=peso; }
    public double getPeso(){ return peso; }
    
    public void setEstatura(double estatura){ this.estatura=estatura; }
    public double getEstatura(){ return estatura; }
    
    public void setIMC(double peso, double estatura){ IMC=peso/(estatura*estatura); this.booleanIMC=true; }
    public double getIMC(){ return IMC; }
    
    public boolean getBooleanIMC(){ return booleanIMC; }
}
